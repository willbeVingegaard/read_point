import requests
import re
import os
import time
html_s='https://www.12365auto.com/dcbg/index'
headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0'}
def get_html(i:int):
    html=html_s+'_'+str(i)+'.shtml'
    response=requests.get(url=html, headers=headers)
    time.sleep(2)
    data=response.text
    url_pattern = r'<h2><a href=[\'"]?([^\'" >]+)'
    global urls
    urls = re.findall(url_pattern, data)

    print(urls)

def get_txt():
    global title_list
    global list_txt
    title_list = []
    list_txt = []
    for i in range(len(urls)):
        text_pattern = r'<p>(.*?)</p>'
        response_url = requests.get(url=urls[i],headers=headers)
        response_url.encoding = 'gb2312'
        data=response_url.text
        texts = re.findall(text_pattern, data, re.DOTALL)
        pattern = r'<h1[^>]*>([^<]+)</h1>'
        title=re.findall(pattern,data)
        str_data=title[0]
        str_data=str_data.replace("/","")
        print(str_data)
        title_list.append(str_data)
        T_DA=''
        for text in texts:
            data=text.strip()[16:]
            T_DA+=data
        list_txt.append(T_DA)
    print(title_list)
    print(list_txt)
    create_txt(title_list, list_txt)
def create_txt(a:list,b:list):
    directory = "C:/Users/24333/Desktop/python/ga/爬虫/txt"
    # 设定你想要创建的文件数量
    num_files =len(a)

    for i in range(num_files):
        # 创建文件名
        filename = os.path.join(directory, f"{a[i]}.txt")

        # 创建并打开文件
        with open(filename, 'w',encoding='utf-8') as f:
            # 在这里你可以写入任何你想要的内容
            f.write(b[i])
for num in range(2,39):
    get_html(num)

    get_txt()